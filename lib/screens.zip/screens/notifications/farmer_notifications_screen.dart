import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../theme/theme.dart';
import '../../services/auth_service.dart';
import '../../services/farmacia_service.dart';

class FarmerNotificationsScreen extends StatefulWidget {
  const FarmerNotificationsScreen({super.key});

  @override
  State<FarmerNotificationsScreen> createState() => _FarmerNotificationsScreenState();
}

class _FarmerNotificationsScreenState extends State<FarmerNotificationsScreen> {
  bool _isLoading = true;
  List<dynamic> _alertas = [];
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadAlertas();
  }

  Future<void> _loadAlertas() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      final authService = AuthService();
      final farmaciaService = FarmaciaService();
      
      final user = authService.currentUser;
      if (user == null) throw Exception('No user authenticated');

      // PRIORIDAD: Obtener el farmacia_id guardado localmente en la sesión
      int? farmaciaId = await authService.getLocalFarmaciaId();

      // Si no está en caché, intentamos re-inicializar el perfil local
      if (farmaciaId == null) {
        await authService.initializeAuth();
        farmaciaId = await authService.getLocalFarmaciaId();
      }

      if (farmaciaId == null) {
        setState(() {
          _error = 'No se encontró la farmacia asociada a tu perfil.';
          _isLoading = false;
        });
        return;
      }

      // Usar el servicio centralizado para obtener alertas de inventario
      final reportes = await farmaciaService.getInventoryReports(farmaciaId);

      if (mounted) {
        setState(() {
          _alertas = reportes;
          _isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _error = 'Error de conexión: no se pudo obtener la información del servidor local.';
          _isLoading = false;
        });
        debugPrint('FarmerNotifications Error: $e');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        title: Text('Alertas Operativas', style: GoogleFonts.manrope(fontWeight: FontWeight.w800)),
        automaticallyImplyLeading: false,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator(color: AppTheme.brandGreen))
          : _error != null
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.error_outline, size: 64, color: AppTheme.danger),
                      const SizedBox(height: 16),
                      Text(_error!, style: const TextStyle(fontSize: 16)),
                      const SizedBox(height: 16),
                      ElevatedButton(onPressed: _loadAlertas, child: const Text('Reintentar'))
                    ],
                  ),
                )
              : _alertas.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(Icons.check_circle_outline, size: 64, color: AppTheme.success),
                          const SizedBox(height: 16),
                          Text('Todo en orden. No hay alertas.', style: GoogleFonts.manrope(fontSize: 16, color: Colors.grey)),
                        ],
                      ),
                    )
                  : RefreshIndicator(
                      onRefresh: _loadAlertas,
                      color: AppTheme.brandGreen,
                      child: ListView.builder(
                        padding: const EdgeInsets.all(16),
                        itemCount: _alertas.length,
                        itemBuilder: (context, index) {
                          final alerta = _alertas[index];
                          final nombre = alerta['nombre'] ?? 'Medicamento';
                          final lote = alerta['lote'] ?? 'Lote N/A';
                          final stock = alerta['stock_actual'] ?? 0;
                          final diasVenc = alerta['dias_para_vencer'];

                          bool isCritico = stock <= 10;
                          bool isVencimiento = diasVenc != null && diasVenc < 30;

                          if (!isCritico && !isVencimiento) return const SizedBox.shrink();

                          return Card(
                            margin: const EdgeInsets.only(bottom: 12),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: BorderSide(color: isCritico ? AppTheme.danger : AppTheme.warning)),
                            elevation: 0,
                            color: isDark ? AppTheme.darkSurface : Colors.white,
                            child: ListTile(
                              leading: Icon(
                                isCritico ? Icons.warning_rounded : Icons.calendar_today_rounded,
                                color: isCritico ? AppTheme.danger : AppTheme.warning,
                                size: 32,
                              ),
                              title: Text('$nombre (Lote: $lote)', style: GoogleFonts.manrope(fontWeight: FontWeight.bold)),
                              subtitle: Text(
                                isCritico ? 'Stock crítico: $stock unidades restantes.' : 'Próximo a vencer en $diasVenc días.',
                                style: TextStyle(color: isDark ? Colors.white70 : Colors.black87),
                              ),
                              trailing: IconButton(
                                icon: const Icon(Icons.arrow_forward_ios, size: 16),
                                onPressed: () {
                                  // Acciones operativas, ej. ir al inventario
                                  Navigator.pushNamed(context, '/inventory-list');
                                },
                              ),
                            ),
                          );
                        },
                      ),
                    ),
    );
  }
}
