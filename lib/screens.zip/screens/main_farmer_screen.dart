import 'package:flutter/material.dart';
import '../theme/theme.dart';
import 'pharmacist_dashboard.dart';
import 'notifications/farmer_notifications_screen.dart';

class MainFarmerScreen extends StatefulWidget {
  const MainFarmerScreen({super.key});

  @override
  State<MainFarmerScreen> createState() => _MainFarmerScreenState();
}

class _MainFarmerScreenState extends State<MainFarmerScreen> {
  int _currentIndex = 0;

  final List<Widget> _screens = [
    const PharmacistDashboard(),
    const FarmerNotificationsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: _screens,
      ),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 10,
              offset: const Offset(0, -5),
            ),
          ],
        ),
        child: NavigationBar(
          selectedIndex: _currentIndex,
          onDestinationSelected: (index) {
            setState(() {
              _currentIndex = index;
            });
          },
          backgroundColor: Theme.of(context).brightness == Brightness.dark ? AppTheme.darkSurface : Colors.white,
          indicatorColor: AppTheme.brandGreen.withOpacity(0.2),
          destinations: const [
            NavigationDestination(
              icon: Icon(Icons.dashboard_outlined),
              selectedIcon: Icon(Icons.dashboard_rounded, color: AppTheme.brandGreen),
              label: 'Panel',
            ),
            NavigationDestination(
              icon: Icon(Icons.notifications_none_rounded),
              selectedIcon: Icon(Icons.notifications_active_rounded, color: AppTheme.brandGreen),
              label: 'Operaciones',
            ),
          ],
        ),
      ),
    );
  }
}
