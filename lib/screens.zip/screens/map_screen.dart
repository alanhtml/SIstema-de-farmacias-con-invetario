import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import '../theme/theme.dart';

class MapScreen extends StatefulWidget {
  const MapScreen({super.key});

  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  GoogleMapController? _mapController;
  Position? _currentPosition;
  
  // 1. Forzar marcadores hardcodeados para la presentación
  final Set<Marker> _markers = {
    const Marker(
      markerId: MarkerId('f1'),
      position: LatLng(-16.5000, -68.1500),
      infoWindow: InfoWindow(title: 'Farmacia San Elías'),
    ),
    const Marker(
      markerId: MarkerId('f2'),
      position: LatLng(-16.5050, -68.1550),
      infoWindow: InfoWindow(title: 'Farmacia Bolivia'),
    ),
  };

  @override
  void initState() {
    super.initState();
    _getUserLocation();
  }

  Future<void> _getUserLocation() async {
    try {
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.whileInUse || permission == LocationPermission.always) {
        final position = await Geolocator.getCurrentPosition();
        if (mounted) setState(() => _currentPosition = position);
      }
    } catch (e) {
      debugPrint('Error GPS: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Red de Farmacias", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        backgroundColor: AppTheme.brandGreen,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: GoogleMap(
        // 2. Posición inicial estricta
        initialCameraPosition: const CameraPosition(
          target: LatLng(-16.5000, -68.1500),
          zoom: 14.0,
        ),
        onMapCreated: (controller) => _mapController = controller,
        markers: _markers, // Usando el set forzado
        myLocationEnabled: true,
        myLocationButtonEnabled: false,
        zoomControlsEnabled: false,
        mapToolbarEnabled: false,
        padding: const EdgeInsets.only(bottom: 100),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          if (_mapController != null && _currentPosition != null) {
            _mapController!.animateCamera(
              CameraUpdate.newLatLngZoom(
                LatLng(_currentPosition!.latitude, _currentPosition!.longitude),
                16.0,
              ),
            );
          }
        },
        backgroundColor: Colors.white,
        child: const Icon(Icons.my_location, color: AppTheme.brandGreen),
      ),
    );
  }
}
