import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:farmacia_app/services/medicamento_service.dart';
import 'package:farmacia_app/theme/theme.dart';

class RegisterMedicineScreen extends StatefulWidget {
  const RegisterMedicineScreen({super.key});

  @override
  State<RegisterMedicineScreen> createState() => _RegisterMedicineScreenState();
}

class _RegisterMedicineScreenState extends State<RegisterMedicineScreen> {
  final _formKey = GlobalKey<FormState>();
  final _medicamentoService = MedicamentoService();

  final _nombreController = TextEditingController();
  final _descripcionController = TextEditingController();
  final _principioActivoController = TextEditingController();

  int? _selectedCategoryId = 1; 
  int? _selectedUnitId = 1;     

  // IDs reales según PostgreSQL (1 al 10)
  final List<Map<String, dynamic>> _categories = [
    {'id': 1, 'nombre': 'Analgésicos'},
    {'id': 2, 'nombre': 'Antipiréticos'},
    {'id': 3, 'nombre': 'Antiinflamatorios'},
    {'id': 4, 'nombre': 'Antibióticos'},
    {'id': 5, 'nombre': 'Antivirales'},
    {'id': 6, 'nombre': 'Antifúngicos'},
    {'id': 7, 'nombre': 'Antidepresivos'},
    {'id': 8, 'nombre': 'Ansiolíticos'},
    {'id': 9, 'nombre': 'Antihistamínicos'},
    {'id': 10, 'nombre': 'Suplementos'},
  ];

  // IDs reales según PostgreSQL (1 al 5)
  final List<Map<String, dynamic>> _units = [
    {'id': 1, 'nombre': 'Tabletas'},
    {'id': 2, 'nombre': 'Cápsulas'},
    {'id': 3, 'nombre': 'Jarabes'},
    {'id': 4, 'nombre': 'Inyectables'},
    {'id': 5, 'nombre': 'Cremas'},
  ];

  bool _isSaving = false;

  Future<void> _registerMedicine() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isSaving = true);

    try {
      final success = await _medicamentoService.registerMedicamentoMaestro({
        'nombre': _nombreController.text.trim(),
        'principio_activo': _principioActivoController.text.trim(),
        'descripcion': _descripcionController.text.trim(),
        'categoria_id': _selectedCategoryId ?? 1,
        'unidad_id': _selectedUnitId ?? 1,
        'stock_total': 100,
        'gtin': null,
        'laboratorio': null,
        'presentacion': null,
        'registro_sanitario': null,
        'lote': "LOTE-TEST",
        'fecha_vencimiento': "2027-12-31",
        'compuesto': null,
      });

      if (mounted) {
        if (success) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Medicamento registrado en el catálogo maestro'),
              backgroundColor: AppTheme.brandGreen,
              behavior: SnackBarBehavior.floating,
            ),
          );
          Navigator.pop(context);
        } else {
          throw Exception('No se pudo registrar el medicamento. Verifica la consola para detalles de Postgres.');
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: ${e.toString()}'),
            backgroundColor: AppTheme.danger,
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: isDark ? AppTheme.darkBackground : Colors.white,
      appBar: AppBar(
        title: Text('Registrar Medicamento',
            style: GoogleFonts.manrope(
                fontWeight: FontWeight.bold,
                color: isDark ? Colors.white : AppTheme.darkText)),
        elevation: 0,
        backgroundColor: isDark ? AppTheme.darkSurface : Colors.white,
        iconTheme: IconThemeData(color: isDark ? Colors.white : AppTheme.darkText),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Catálogo Maestro',
                  style: GoogleFonts.manrope(
                      fontSize: 18,
                      fontWeight: FontWeight.w800,
                      color: isDark ? AppTheme.brightGreen : AppTheme.brandGreen)),
              const SizedBox(height: 8),
              Text('Añade un nuevo producto al sistema global utilizando los catálogos verificados.',
                  style: TextStyle(color: isDark ? Colors.white70 : Colors.grey.shade600)),
              const SizedBox(height: 32),
              _buildTextField('Nombre Comercial', _nombreController, Icons.medication, isDark),
              const SizedBox(height: 16),
              _buildTextField('Principio Activo', _principioActivoController, Icons.science, isDark),
              const SizedBox(height: 16),
              
              _buildDropdownField(
                'Categoría Farmacéutica', 
                _selectedCategoryId, 
                _categories, 
                Icons.category_rounded, 
                isDark,
                (val) => setState(() => _selectedCategoryId = val)
              ),
              const SizedBox(height: 16),

              _buildDropdownField(
                'Unidad de Presentación', 
                _selectedUnitId, 
                _units, 
                Icons.inventory_2_rounded, 
                isDark,
                (val) => setState(() => _selectedUnitId = val)
              ),
              const SizedBox(height: 16),

              _buildTextField('Descripción Detallada', _descripcionController, Icons.description, isDark, maxLines: 3),
              const SizedBox(height: 40),
              SizedBox(
                width: double.infinity,
                height: 56,
                child: ElevatedButton(
                  onPressed: _isSaving ? null : _registerMedicine,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: isDark ? AppTheme.brightGreen : AppTheme.brandGreen,
                    foregroundColor: isDark ? Colors.black : Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    elevation: 0,
                  ),
                  child: _isSaving
                      ? CircularProgressIndicator(color: isDark ? Colors.black : Colors.white)
                      : const Text('REGISTRAR PRODUCTO',
                          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(
      String label, TextEditingController controller, IconData icon, bool isDark,
      {int maxLines = 1}) {
    return TextFormField(
      controller: controller,
      maxLines: maxLines,
      style: TextStyle(color: isDark ? Colors.white : AppTheme.darkText),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: TextStyle(color: isDark ? Colors.white70 : Colors.grey.shade600),
        prefixIcon: Icon(icon, color: isDark ? AppTheme.brightGreen : AppTheme.brandGreen),
        filled: true,
        fillColor: isDark ? AppTheme.darkSurface : AppTheme.softGrey,
        border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
        alignLabelWithHint: true,
      ),
      validator: (value) => value == null || value.isEmpty ? 'Requerido' : null,
    );
  }

  Widget _buildDropdownField(String label, int? value, List<Map<String, dynamic>> items, IconData icon, bool isDark, Function(int?) onChanged) {
    return DropdownButtonFormField<int>(
      value: value,
      items: items.map((item) => DropdownMenuItem<int>(
        value: item['id'],
        child: Text(item['nombre'], style: TextStyle(color: isDark ? Colors.white : AppTheme.darkText)),
      )).toList(),
      onChanged: onChanged,
      dropdownColor: isDark ? AppTheme.darkSurface : Colors.white,
      decoration: InputDecoration(
        labelText: label,
        labelStyle: TextStyle(color: isDark ? Colors.white70 : Colors.grey.shade600),
        prefixIcon: Icon(icon, color: isDark ? AppTheme.brightGreen : AppTheme.brandGreen),
        filled: true,
        fillColor: isDark ? AppTheme.darkSurface : AppTheme.softGrey,
        border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
      ),
      validator: (value) => value == null ? 'Selección requerida' : null,
    );
  }
}
