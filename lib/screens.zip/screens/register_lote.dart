import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:farmacia_app/theme/theme.dart';
import 'package:farmacia_app/services/auth_service.dart';
import 'package:farmacia_app/config/constants.dart';

class RegisterLoteScreen extends StatefulWidget {
  const RegisterLoteScreen({super.key});

  @override
  State<RegisterLoteScreen> createState() => _RegisterLoteScreenState();
}

class _RegisterLoteScreenState extends State<RegisterLoteScreen> {
  final _formKey = GlobalKey<FormState>();
  final _supabase = Supabase.instance.client;
  final _authService = AuthService();

  final _codigoLoteController = TextEditingController();
  final _cantidadController = TextEditingController();
  final _vencimientoController = TextEditingController();

  String? _selectedMedicationId;
  List<Map<String, dynamic>> _medications = [];
  bool _isLoadingMedications = true;
  bool _isSaving = false;
  int? _farmaciaId;

  @override
  void initState() {
    super.initState();
    _loadInitialData();
  }

  Future<void> _loadInitialData() async {
    try {
      final medData = await _supabase.from('inventario_medicamentos').select('id, nombre').order('nombre');
      final user = _authService.currentUser;
      if (user != null) {
        final profile = await _authService.getUserProfile(user.id);
        if (mounted) {
          setState(() {
            _farmaciaId = profile?['farmacia_id'];
            _medications = List<Map<String, dynamic>>.from(medData);
            
            final args = ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;
            if (args != null && args.containsKey('medicamentoId')) {
              _selectedMedicationId = args['medicamentoId'].toString();
            }
            _isLoadingMedications = false;
          });
        }
      }
    } catch (e) {
      if (mounted) setState(() => _isLoadingMedications = false);
    }
  }

  Future<void> _selectDate() async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now().add(const Duration(days: 365)),
      firstDate: DateTime.now(),
      lastDate: DateTime(2035),
    );
    if (picked != null) {
      setState(() => _vencimientoController.text = picked.toIso8601String().split('T')[0]);
    }
  }

  Future<void> _saveLote() async {
    if (!_formKey.currentState!.validate() || _isSaving) return;
    if (_farmaciaId == null) {
       ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Error: Farmacia no identificada'), backgroundColor: AppTheme.danger));
       return;
    }

    setState(() => _isSaving = true);
    try {
      final url = Uri.parse('$baseUrl/api/lotes');
      final response = await http.post(
        url,
        headers: {
          'Content-Type': 'application/json',
          'rol': 'farmaceutico',
        },
        body: json.encode({
          'medicamento_id': _selectedMedicationId,
          'numero_lote': _codigoLoteController.text.trim(),
          'cantidad_inicial': int.parse(_cantidadController.text.trim()),
          'cantidad_actual': int.parse(_cantidadController.text.trim()),
          'fecha_vencimiento': _vencimientoController.text,
          'farmacia_id': _farmaciaId,
        }),
      ).timeout(const Duration(seconds: 10));

      if (mounted) {
        if (response.statusCode == 200 || response.statusCode == 201) {
          _clearFields();
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Lote registrado exitosamente'), backgroundColor: AppTheme.success));
          Navigator.pop(context, true); // Retorna true para refrescar el dashboard
        } else {
          throw Exception('Error del servidor: ${response.statusCode}');
        }
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e'), backgroundColor: AppTheme.danger));
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }
  }

  void _clearFields() {
    _codigoLoteController.clear();
    _cantidadController.clear();
    _vencimientoController.clear();
    setState(() => _selectedMedicationId = null);
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Scaffold(
      backgroundColor: isDark ? AppTheme.darkBackground : AppTheme.softGrey,
      appBar: AppBar(
        title: Text('Nuevo Lote', style: GoogleFonts.manrope(fontWeight: FontWeight.bold)),
        elevation: 0,
        backgroundColor: isDark ? AppTheme.darkSurface : Colors.white,
      ),
      body: _isLoadingMedications 
        ? const Center(child: CircularProgressIndicator(color: AppTheme.brandGreen))
        : SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Detalles de Ingreso', style: GoogleFonts.manrope(fontSize: 22, fontWeight: FontWeight.w800, color: AppTheme.brandGreen)),
                  const SizedBox(height: 24),
                  DropdownButtonFormField<String>(
                    value: _selectedMedicationId,
                    dropdownColor: isDark ? AppTheme.darkSurface : Colors.white,
                    decoration: _inputDeco('Medicamento', Icons.medication, isDark),
                    items: _medications.map((m) => DropdownMenuItem(value: m['id'].toString(), child: Text(m['nombre']))).toList(),
                    onChanged: (v) => setState(() => _selectedMedicationId = v),
                    validator: (v) => v == null ? 'Campo requerido' : null,
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: _codigoLoteController,
                    decoration: _inputDeco('Código/Número de Lote', Icons.tag, isDark),
                    validator: (v) => v!.isEmpty ? 'Campo requerido' : null,
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: _cantidadController,
                    keyboardType: TextInputType.number,
                    decoration: _inputDeco('Cantidad Recibida', Icons.inventory, isDark),
                    validator: (v) => v!.isEmpty ? 'Campo requerido' : null,
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: _vencimientoController,
                    readOnly: true,
                    onTap: _selectDate,
                    decoration: _inputDeco('Fecha de Vencimiento', Icons.calendar_today, isDark),
                    validator: (v) => v!.isEmpty ? 'Campo requerido' : null,
                  ),
                  const SizedBox(height: 40),
                  SizedBox(
                    width: double.infinity,
                    height: 56,
                    child: ElevatedButton(
                      onPressed: _isSaving ? null : _saveLote,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppTheme.brandGreen,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      child: _isSaving ? const CircularProgressIndicator(color: Colors.white) : const Text('REGISTRAR LOTE', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                    ),
                  ),
                ],
              ),
            ),
          ),
    );
  }

  InputDecoration _inputDeco(String label, IconData icon, bool isDark) {
    return InputDecoration(
      labelText: label,
      prefixIcon: Icon(icon, color: AppTheme.brandGreen),
      filled: true,
      fillColor: isDark ? AppTheme.darkSurface : Colors.white,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
    );
  }
}
