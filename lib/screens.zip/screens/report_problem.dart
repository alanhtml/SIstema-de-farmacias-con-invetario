import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:farmacia_app/theme/theme.dart';
import 'package:farmacia_app/services/medicamento_service.dart';
import 'package:farmacia_app/services/auth_service.dart';

class ReportProblemScreen extends StatefulWidget {
  final Map<String, dynamic>? productData;
  const ReportProblemScreen({super.key, this.productData});

  @override
  State<ReportProblemScreen> createState() => _ReportProblemScreenState();
}

class _ReportProblemScreenState extends State<ReportProblemScreen> {
  final _nameController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _medService = MedicamentoService();
  final _authService = AuthService();
  bool _isSaving = false;

  @override
  void initState() {
    super.initState();
    if (widget.productData != null) {
      _nameController.text = widget.productData?['nombre'] ?? '';
    }
  }

  Future<void> _sendReport() async {
    if (_nameController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Por favor, ingresa el nombre del fármaco')),
      );
      return;
    }
    if (_descriptionController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Por favor, describe el problema')),
      );
      return;
    }

    setState(() => _isSaving = true);
    try {
      final user = _authService.currentUser;
      if (user == null) throw Exception('ID de usuario no encontrado');

      // Obtener el ID local sincronizado
      final localId = await _authService.getLocalUserId();
      if (localId == null) throw Exception('No se encontró el ID local del usuario. Por favor, re-inicia sesión.');

      // Debug Payload
      print("📦 Payload enviado: {usuario_id: $localId, medicamento_id: ${widget.productData?['medicamento_id'] ?? '0'}, nombre_farmaco: ${_nameController.text.trim()}}");

      final success = await _medService.reportarIncidencia(
        usuarioId: localId.toString(),
        medicamentoId: widget.productData?['medicamento_id']?.toString() ?? '0',
        nombreFarmaco: _nameController.text.trim(),
        descripcion: _descriptionController.text.trim(),
      );

      if (mounted && success) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Reporte enviado con éxito'), backgroundColor: AppTheme.success),
        );
        Navigator.pop(context);
      }
    } catch (e) {
      print("❌ EXCEPCIÓN EN CAPA UI: $e");
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: $e'), 
            backgroundColor: AppTheme.danger,
            duration: const Duration(seconds: 5),
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: isDark ? AppTheme.darkBackground : AppTheme.softGrey,
      appBar: AppBar(
        title: Text('Reportar Problema', style: GoogleFonts.manrope(fontWeight: FontWeight.bold)),
        backgroundColor: isDark ? AppTheme.darkSurface : Colors.white,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Nombre del Fármaco:', 
              style: GoogleFonts.manrope(fontSize: 15, fontWeight: FontWeight.w600)),
            const SizedBox(height: 12),
            TextField(
              controller: _nameController,
              enabled: widget.productData == null,
              decoration: InputDecoration(
                hintText: 'Ej: Paracetamol 500mg',
                filled: true,
                fillColor: isDark ? AppTheme.darkSurface : Colors.white,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
              ),
            ),
            const SizedBox(height: 24),
            Text('Lote o Descripción del problema:', 
              style: GoogleFonts.manrope(fontSize: 15, fontWeight: FontWeight.w600)),
            const SizedBox(height: 12),
            TextField(
              controller: _descriptionController,
              maxLines: 6,
              decoration: InputDecoration(
                hintText: 'Describe el problema, lote, fecha de vencimiento sospechosa, etc.',
                filled: true,
                fillColor: isDark ? AppTheme.darkSurface : Colors.white,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
              ),
            ),
            const SizedBox(height: 32),
            SizedBox(
              width: double.infinity,
              height: 56,
              child: ElevatedButton.icon(
                onPressed: _isSaving ? null : _sendReport,
                icon: const Icon(Icons.send_rounded, color: Colors.white),
                label: const Text('ENVIAR REPORTE', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.danger,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
