import 'dart:async';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:farmacia_app/theme/theme.dart';
import 'package:farmacia_app/services/auth_service.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

enum UserRole { cliente, farmaceutico }

class _RegisterScreenState extends State<RegisterScreen>
    with SingleTickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();
  final _pharmacyNameController = TextEditingController();
  final _pharmacyAddressController = TextEditingController();
  final AuthService _authService = AuthService();

  double? _latitude;
  double? _longitude;
  bool _gettingLocation = false;
  bool _isRegistering = false;

  UserRole _selectedRole = UserRole.cliente;
  bool _obscurePassword = true;
  bool _obscureConfirmPassword = true;
  bool _acceptedTerms = false;
  StreamSubscription<AuthState>? _authSubscription;

  late AnimationController _animController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _animController = AnimationController(vsync: this, duration: const Duration(milliseconds: 350));
    _fadeAnimation = CurvedAnimation(parent: _animController, curve: Curves.easeInOut);

    // 2. Escucha del Estado de Autenticación en Tiempo Real
    _authSubscription = Supabase.instance.client.auth.onAuthStateChange.listen((data) {
      if (data.event == AuthChangeEvent.signedIn) {
        // En el milisegundo en que el usuario confirma el mail, redirige de inmediato
        _authSubscription?.cancel();
        if (mounted) {
          _clearControllers();
          Navigator.pushNamedAndRemoveUntil(context, '/welcome', (route) => false);
        }
      }
    });
  }

  void _clearControllers() {
    _nameController.clear();
    _emailController.clear();
    _passwordController.clear();
    _confirmPasswordController.clear();
    _pharmacyNameController.clear();
    _pharmacyAddressController.clear();
  }

  @override
  void dispose() {
    _authSubscription?.cancel();
    _nameController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    _pharmacyNameController.dispose();
    _pharmacyAddressController.dispose();
    _animController.dispose();
    super.dispose();
  }

  void _setRole(UserRole role) {
    setState(() => _selectedRole = role);
    if (role == UserRole.farmaceutico) {
      _animController.forward();
    } else {
      _animController.reverse();
    }
  }

  Future<void> _register() async {
    if (_isRegistering) return;
    
    // Validaciones previas
    if (!_formKey.currentState!.validate()) return;
    
    if (_passwordController.text != _confirmPasswordController.text) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Las contraseñas no coinciden'),
        backgroundColor: AppTheme.danger,
        behavior: SnackBarBehavior.floating,
      ));
      return;
    }

    if (!_acceptedTerms) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Debes aceptar los términos y condiciones'),
        backgroundColor: AppTheme.danger,
        behavior: SnackBarBehavior.floating,
      ));
      return;
    }

    setState(() => _isRegistering = true);

    try {
      // --- VALIDACIÓN DE CONEXIÓN PREVIA ---
      // El método signUp de AuthService ahora garantiza que el backend responda 
      // antes de comprometer el registro en Supabase.
      final response = await _authService.signUp(
        email: _emailController.text.trim(),
        password: _passwordController.text.trim(),
        nombre: _nameController.text.trim(),
        rol: _selectedRole == UserRole.farmaceutico ? 'farmaceutico' : 'cliente',
        farmaciaNombre: _selectedRole == UserRole.farmaceutico ? _pharmacyNameController.text.trim() : null,
        farmaciaDireccion: _selectedRole == UserRole.farmaceutico ? _pharmacyAddressController.text.trim() : null,
      );

      if (!mounted) return;

      if (response.user != null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Row(
              children: [
                const Icon(Icons.mark_email_read_rounded, color: Colors.white, size: 28),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('📨 Enlace de verificación enviado', 
                        style: GoogleFonts.manrope(fontWeight: FontWeight.w800, fontSize: 14)),
                      Text('Por favor, abre tu correo electrónico para activar tu cuenta.',
                        style: GoogleFonts.manrope(fontSize: 12, color: Colors.white.withOpacity(0.9))),
                    ],
                  ),
                ),
              ],
            ),
            backgroundColor: AppTheme.brandGreen,
            behavior: SnackBarBehavior.floating,
            duration: const Duration(seconds: 15),
            margin: const EdgeInsets.all(20),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
          ),
        );
      }
    } catch (e) {
      if (!mounted) return;
      String errorMsg = e.toString();
      
      if (errorMsg.contains('TimeoutException') || errorMsg.contains('Connection refused')) {
        errorMsg = "⚠️ No se pudo conectar con el servidor local. Verifica que el backend esté encendido en el puerto 3000.";
      } else if (errorMsg.contains('User already registered') || errorMsg.contains('email already exists')) {
        errorMsg = "Este correo ya está registrado, por favor inicia sesión.";
      }
      
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(errorMsg.replaceAll('Exception: ', '')),
        backgroundColor: AppTheme.danger,
        behavior: SnackBarBehavior.floating,
      ));
    } finally {
      if (mounted) setState(() => _isRegistering = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Scaffold(
      backgroundColor: AppTheme.softGrey,
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildBackButton(context),
                const SizedBox(height: 16),
                _buildHeader(),
                const SizedBox(height: 32),
                Container(
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 24, offset: const Offset(0, 8))],
                  ),
                  child: Form(
                    key: _formKey,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildRoleSelector(colors),
                        const SizedBox(height: 24),
                        _buildTextField(controller: _nameController, label: 'Nombre Completo', hint: 'Ej. Guido Mendoza Mamani', icon: Icons.person_outline_rounded, validator: (v) => (v == null || v.trim().isEmpty) ? 'Ingresa tu nombre' : null),
                        const SizedBox(height: 16),
                        _buildTextField(controller: _emailController, label: 'Correo Electrónico', hint: 'ejemplo@correo.com', icon: Icons.email_outlined, keyboardType: TextInputType.emailAddress, validator: (v) {
                          if (v == null || v.trim().isEmpty) return 'Ingresa tu correo';
                          if (!RegExp(r'^[\w-/.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(v)) return 'Ingresa un correo válido';
                          return null;
                        }),
                        const SizedBox(height: 16),
                        _buildTextField(controller: _passwordController, label: 'Contraseña', hint: '••••••••', icon: Icons.lock_outline_rounded, obscure: _obscurePassword, suffixIcon: IconButton(icon: Icon(_obscurePassword ? Icons.visibility_off_outlined : Icons.visibility_outlined, color: Colors.grey.shade400, size: 20), onPressed: () => setState(() => _obscurePassword = !_obscurePassword)), validator: (v) {
                          if (v == null || v.isEmpty) return 'Ingresa una contraseña';
                          if (v.length < 6) return 'Mínimo 6 caracteres';
                          return null;
                        }),
                        const SizedBox(height: 16),
                        _buildTextField(controller: _confirmPasswordController, label: 'Confirmar Contraseña', hint: '••••••••', icon: Icons.lock_outline_rounded, obscure: _obscureConfirmPassword, suffixIcon: IconButton(icon: Icon(_obscureConfirmPassword ? Icons.visibility_off_outlined : Icons.visibility_outlined, color: Colors.grey.shade400, size: 20), onPressed: () => setState(() => _obscureConfirmPassword = !_obscureConfirmPassword)), validator: (v) {
                          if (v == null || v.isEmpty) return 'Confirma tu contraseña';
                          if (v != _passwordController.text) return 'Las contraseñas no coinciden';
                          return null;
                        }),
                        SizeTransition(
                          sizeFactor: _fadeAnimation,
                          axisAlignment: -1.0,
                          child: FadeTransition(
                            opacity: _fadeAnimation,
                            child: Column(children: [
                              const SizedBox(height: 16),
                              _buildDividerWithLabel('Datos de la Farmacia'),
                              const SizedBox(height: 16),
                              _buildTextField(controller: _pharmacyNameController, label: 'Nombre de la Farmacia', hint: 'Ej. Farmacia Cruz Verde', icon: Icons.local_pharmacy_outlined, validator: _selectedRole == UserRole.farmaceutico ? (v) => (v == null || v.trim().isEmpty) ? 'Ingresa el nombre de la farmacia' : null : null),
                              const SizedBox(height: 16),
                              _buildTextField(
                                controller: _pharmacyAddressController, 
                                label: 'Dirección de la Farmacia', 
                                hint: 'Ej. Av. Principal #123', 
                                icon: Icons.location_on_outlined, 
                                suffixIcon: _selectedRole == UserRole.farmaceutico 
                                  ? IconButton(
                                      icon: _gettingLocation 
                                        ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: AppTheme.brandGreen))
                                        : const Icon(Icons.my_location, color: AppTheme.brandGreen),
                                      onPressed: _getCurrentLocation,
                                      tooltip: "Obtener ubicación actual",
                                    )
                                  : null,
                                validator: _selectedRole == UserRole.farmaceutico ? (v) => (v == null || v.trim().isEmpty) ? 'Ingresa la dirección de la farmacia' : null : null
                              ),
                            ]),
                          ),
                        ),
                        const SizedBox(height: 24),
                        _buildTermsCheckbox(colors),
                        const SizedBox(height: 24),
                        _buildRegisterButton(),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 24),
                _buildLoginLink(),
                const SizedBox(height: 24),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildBackButton(BuildContext context) {
    return GestureDetector(
      onTap: () => Navigator.pop(context),
      child: Container(
        width: 44, height: 44,
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8, offset: const Offset(0, 2))]),
        child: const Icon(Icons.arrow_back_ios_new_rounded, size: 18),
      ),
    );
  }

  Widget _buildHeader() {
    return Center(
      child: Column(
        children: [
          Image.asset(
            'assets/images/logo_completo.png',
            height: 120,
            fit: BoxFit.contain,
            errorBuilder: (context, error, stackTrace) => const Icon(Icons.medical_services, size: 80, color: AppTheme.brandGreen),
          ),
          const SizedBox(height: 30),
          Text(
            'Completa tus datos para unirte a Medivida',
            textAlign: TextAlign.center,
            style: GoogleFonts.manrope(
              fontSize: 15,
              fontWeight: FontWeight.w500,
              color: Colors.grey.shade500,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRoleSelector(ColorScheme colors) {
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(color: AppTheme.softGrey, borderRadius: BorderRadius.circular(16)),
      child: Row(children: [
        _buildRoleTab(label: 'Cliente', icon: Icons.person_rounded, isSelected: _selectedRole == UserRole.cliente, onTap: () => _setRole(UserRole.cliente), colors: colors),
        _buildRoleTab(label: 'Farmacéutico', icon: Icons.local_pharmacy_rounded, isSelected: _selectedRole == UserRole.farmaceutico, onTap: () => _setRole(UserRole.farmaceutico), colors: colors),
      ]),
    );
  }

  Widget _buildRoleTab({required String label, required IconData icon, required bool isSelected, required VoidCallback onTap, required ColorScheme colors}) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeInOut,
          padding: const EdgeInsets.symmetric(vertical: 14),
          decoration: BoxDecoration(
            color: isSelected ? Colors.white : Colors.transparent,
            borderRadius: BorderRadius.circular(12),
            boxShadow: isSelected ? [BoxShadow(color: AppTheme.brandGreen.withOpacity(0.12), blurRadius: 8, offset: const Offset(0, 2))] : [],
          ),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(icon, size: 18, color: isSelected ? AppTheme.brandGreen : Colors.grey.shade400),
            const SizedBox(width: 8),
            Text(label, style: GoogleFonts.manrope(fontSize: 14, fontWeight: FontWeight.w700, color: isSelected ? AppTheme.brandGreen : Colors.grey.shade500)),
          ]),
        ),
      ),
    );
  }

  Widget _buildTextField({required TextEditingController controller, required String label, required String hint, required IconData icon, TextInputType keyboardType = TextInputType.text, bool obscure = false, Widget? suffixIcon, String? Function(String?)? validator}) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(label.toUpperCase(), style: GoogleFonts.manrope(fontSize: 11, fontWeight: FontWeight.w700, color: AppTheme.brandGreen, letterSpacing: 1.2)),
      const SizedBox(height: 8),
      TextFormField(
        controller: controller, obscureText: obscure, keyboardType: keyboardType, validator: validator,
        style: GoogleFonts.manrope(fontSize: 15, fontWeight: FontWeight.w500, color: AppTheme.darkText),
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: GoogleFonts.manrope(fontSize: 14, color: Colors.grey.shade400),
          prefixIcon: Padding(padding: const EdgeInsets.only(left: 16, right: 12), child: Icon(icon, size: 20, color: Colors.grey.shade400)),
          prefixIconConstraints: const BoxConstraints(minWidth: 0, minHeight: 0),
          suffixIcon: suffixIcon,
          filled: true, fillColor: AppTheme.softGrey,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: AppTheme.brandGreen, width: 1.5)),
          errorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: AppTheme.danger, width: 1.5)),
          focusedErrorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: AppTheme.danger, width: 1.5)),
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        ),
      ),
    ]);
  }

  Widget _buildDividerWithLabel(String label) {
    return Row(children: [
      Expanded(child: Divider(color: Colors.grey.shade200, thickness: 1)),
      Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: Text(label, style: GoogleFonts.manrope(fontSize: 12, fontWeight: FontWeight.w600, color: Colors.grey.shade400))),
      Expanded(child: Divider(color: Colors.grey.shade200, thickness: 1)),
    ]);
  }

  Widget _buildTermsCheckbox(ColorScheme colors) {
    return Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      SizedBox(width: 22, height: 22, child: Checkbox(value: _acceptedTerms, onChanged: (v) => setState(() => _acceptedTerms = v ?? false), activeColor: AppTheme.brandGreen, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)), side: BorderSide(color: Colors.grey.shade300, width: 1.5))),
      const SizedBox(width: 12),
      Expanded(child: Text.rich(TextSpan(text: 'Acepto los ', style: GoogleFonts.manrope(fontSize: 13, color: Colors.grey.shade600), children: [
        TextSpan(text: 'Términos de Servicio', style: GoogleFonts.manrope(fontSize: 13, color: AppTheme.brandGreen, fontWeight: FontWeight.w700)),
        const TextSpan(text: ' y la '),
        TextSpan(text: 'Política de Privacidad', style: GoogleFonts.manrope(fontSize: 13, color: AppTheme.brandGreen, fontWeight: FontWeight.w700)),
      ]))),
    ]);
  }

  Widget _buildRegisterButton() {
    return Container(
      width: double.infinity, height: 56,
      decoration: BoxDecoration(gradient: AppTheme.primaryGradient, borderRadius: BorderRadius.circular(12), boxShadow: [BoxShadow(color: AppTheme.brandGreen.withOpacity(0.3), blurRadius: 16, offset: const Offset(0, 6))]),
      child: Material(
        color: Colors.transparent, 
        child: InkWell(
          onTap: _isRegistering ? null : _register, 
          borderRadius: BorderRadius.circular(12), 
          child: Center(
            child: _isRegistering 
              ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
              : Text('Crear Cuenta', style: GoogleFonts.manrope(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w700))
          )
        )
      ),
    );
  }

  Widget _buildLoginLink() {
    return Center(child: Text.rich(TextSpan(
      text: '¿Ya tienes cuenta? ',
      style: GoogleFonts.manrope(fontSize: 14, color: Colors.grey.shade500, fontWeight: FontWeight.w500),
      children: [WidgetSpan(alignment: PlaceholderAlignment.baseline, baseline: TextBaseline.alphabetic, child: GestureDetector(onTap: () => Navigator.pushNamed(context, '/login'), child: Text('Inicia Sesión', style: GoogleFonts.manrope(fontSize: 14, color: AppTheme.brandGreen, fontWeight: FontWeight.w800))))],
    )));
  }

  Future<void> _getCurrentLocation() async {
    setState(() => _gettingLocation = true);
    try {
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }

      if (permission == LocationPermission.whileInUse || permission == LocationPermission.always) {
        Position position = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.high
        );
        
        setState(() {
          _latitude = position.latitude;
          _longitude = position.longitude;
          _pharmacyAddressController.text = "Ubicación GPS: ${_latitude!.toStringAsFixed(6)}, ${_longitude!.toStringAsFixed(6)}";
        });

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Ubicación obtenida correctamente'),
            backgroundColor: AppTheme.brandGreen,
            behavior: SnackBarBehavior.floating,
          ),
        );
      } else {
        throw Exception('Permiso de ubicación denegado');
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error al obtener ubicación: $e'),
          backgroundColor: AppTheme.danger,
          behavior: SnackBarBehavior.floating,
        ),
      );
    } finally {
      setState(() => _gettingLocation = false);
    }
  }
}
