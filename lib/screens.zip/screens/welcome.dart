import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:farmacia_app/theme/theme.dart';
import 'package:farmacia_app/services/auth_service.dart';

class WelcomeScreen extends StatefulWidget {
  const WelcomeScreen({super.key});

  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen> {
  final AuthService _authService = AuthService();
  bool _isLoading = false;

  Future<void> _handlePrimaryAction() async {
    final user = _authService.currentUser;
    
    if (user == null) {
      Navigator.pushNamed(context, '/login');
      return;
    }

    setState(() => _isLoading = true);
    try {
      // Petición limpia para verificar el ROL REAL en PostgreSQL
      final String? role = await _authService.initializeAuth();
      
      if (!mounted) return;

      if (role == 'farmaceutico') {
        print("🟢 Acceso concedido: Perfil Farmacéutico detectado.");
        Navigator.pushReplacementNamed(context, '/inventory-list');
      } else if (role == 'cliente' || role == 'usuario') {
        print("🔵 Acceso concedido: Perfil Cliente detectado.");
        Navigator.pushReplacementNamed(context, '/medication-search');
      } else {
        // Bloqueo preventivo: No conocemos este rol o el backend no respondió datos válidos
        print("🔴 Error: Rol no reconocido o perfil incompleto.");
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('⚠️ Tu perfil aún no está sincronizado. Por favor, re-inicia sesión.'),
            backgroundColor: AppTheme.warning,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error de conexión: $e'), backgroundColor: AppTheme.danger),
        );
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Spacer(),
              Image.asset(
                'assets/images/logo_completo.png',
                width: 280,
                fit: BoxFit.contain,
                errorBuilder: (context, error, stackTrace) => 
                    const Icon(Icons.medical_services, size: 100, color: AppTheme.brandGreen),
              ),
              const SizedBox(height: 40),
              Text(
                'Seguridad en cada dosis',
                textAlign: TextAlign.center,
                style: GoogleFonts.manrope(
                  fontSize: 24,
                  fontWeight: FontWeight.w800,
                  color: AppTheme.darkText,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                'Verifica la autenticidad de tus medicamentos y gestiona tu inventario de forma profesional.',
                textAlign: TextAlign.center,
                style: GoogleFonts.manrope(
                  fontSize: 16,
                  color: Colors.grey.shade600,
                  height: 1.5,
                ),
              ),
              const Spacer(),
              SizedBox(
                width: double.infinity,
                height: 56,
                child: ElevatedButton(
                  onPressed: _isLoading ? null : _handlePrimaryAction,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppTheme.brandGreen,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    elevation: 0,
                  ),
                  child: _isLoading 
                    ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                    : const Text('EMPEZAR AHORA', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1)),
                ),
              ),
              const SizedBox(height: 16),
              if (_authService.currentUser == null)
                SizedBox(
                  width: double.infinity,
                  height: 56,
                  child: OutlinedButton(
                    onPressed: () => Navigator.pushNamed(context, '/register'),
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: AppTheme.brandGreen, width: 2),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    child: const Text('CREAR CUENTA', style: TextStyle(color: AppTheme.brandGreen, fontWeight: FontWeight.bold, letterSpacing: 1)),
                  ),
                ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}

