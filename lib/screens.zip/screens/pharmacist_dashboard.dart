import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:google_fonts/google_fonts.dart';
import '../config/constants.dart';
import '../theme/theme.dart';
import '../services/auth_service.dart';

class PharmacistDashboard extends StatefulWidget {
  const PharmacistDashboard({super.key});

  @override
  State<PharmacistDashboard> createState() => _PharmacistDashboardState();
}

class _PharmacistDashboardState extends State<PharmacistDashboard> {
  bool _loading = true;
  String? _error;
  int _totalStock = 0;
  int _alertas = 0;
  int _escaneos = 0;
  String _userName = 'Farmacéutico';
  int? _farmaciaId;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    if (!mounted) return;
    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final user = AuthService().currentUser;
      if (user != null) {
        // Obtenemos el perfil con manejo de nulos para evitar el error PGRST116
        final profile = await AuthService().getUserProfile(user.id).timeout(const Duration(seconds: 10));
        
        if (mounted) {
          setState(() {
            _userName = user.userMetadata?['full_name'] ?? profile?['nombre'] ?? 'Farmacéutico';
            _farmaciaId = profile?['farmacia_id'];
          });
        }
      }

      // Si no hay farmacia_id, usamos el 1 por defecto para la demo, pero avisamos
      final idToQuery = _farmaciaId ?? 1;
      
      final url = Uri.parse('$baseUrl/api/dashboard/resumen/$idToQuery');
      final response = await http.get(
        url,
        headers: {
          'Content-Type': 'application/json',
          'rol': 'farmaceutico',
        },
      ).timeout(const Duration(seconds: 10));

      if (!mounted) return;

      if (response.statusCode == 200) {
        final body = json.decode(response.body);
        final data = body['data'] ?? {};
        setState(() {
          _totalStock = data['total_stock'] ?? 0;
          _alertas = data['alerts'] ?? 0;
          _escaneos = data['scans_today'] ?? 0;
          _loading = false;
        });

        if (_alertas > 0) {
          _showAutoAlert();
        }
      } else {
        setState(() {
          _error = 'Error del servidor (${response.statusCode}). Verifica que el backend esté corriendo.';
          _loading = false;
        });
      }
    } on TimeoutException {
      if (mounted) {
        setState(() {
          _error = 'Tiempo de espera agotado. Verifica la conexión con $baseUrl';
          _loading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _error = 'Error de inicialización: $e';
          _loading = false;
        });
      }
    }
  }

  void _showAutoAlert() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: Row(
            children: [
              const Icon(Icons.warning_amber_rounded, color: AppTheme.warning, size: 28),
              const SizedBox(width: 12),
              Text('¡Atención de Stock!', style: GoogleFonts.manrope(fontWeight: FontWeight.bold)),
            ],
          ),
          content: const Text('Existen medicamentos próximos a vencer o con stock crítico. Revisa los reportes.'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('ENTENDIDO', style: TextStyle(color: AppTheme.brandGreen, fontWeight: FontWeight.bold)),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
                Navigator.pushNamed(context, '/report');
              },
              style: ElevatedButton.styleFrom(backgroundColor: AppTheme.brandGreen),
              child: const Text('VER REPORTES', style: TextStyle(color: Colors.white)),
            ),
          ],
        ),
      );
    });
  }

  Future<void> _logout() async {
    try {
      await AuthService().signOut();
      if (mounted) {
        Navigator.pushNamedAndRemoveUntil(context, '/login', (route) => false);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error al cerrar sesión: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Image.asset(
              'assets/images/logo_icono.png',
              height: 28,
              errorBuilder: (context, error, stackTrace) => 
                  const Icon(Icons.local_pharmacy_rounded, color: AppTheme.brandGreen, size: 28),
            ),
            const SizedBox(width: 10),
            Text('Medivida', style: GoogleFonts.manrope(fontWeight: FontWeight.w900, letterSpacing: 0.5)),
          ],
        ),
        automaticallyImplyLeading: false,
        actions: [
          IconButton(
            icon: Icon(isDark ? Icons.light_mode : Icons.dark_mode),
            onPressed: () => AppTheme.themeNotifier.value = isDark ? ThemeMode.light : ThemeMode.dark,
          ),
          IconButton(
            icon: const Icon(Icons.person_outline),
            onPressed: () => Navigator.pushNamed(context, '/profile'),
          ),
          IconButton(icon: const Icon(Icons.logout), onPressed: _logout),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: AppTheme.brandGreen))
          : _error != null
              ? _buildErrorView()
              : RefreshIndicator(
                  onRefresh: _loadData,
                  child: _buildContent(isDark),
                ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          final result = await Navigator.pushNamed(context, '/registro-lote');
          if (result == true) _loadData();
        },
        backgroundColor: AppTheme.brandGreen,
        icon: const Icon(Icons.add_box_rounded, color: Colors.white),
        label: const Text('NUEVO LOTE', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
      ),
    );
  }

  Widget _buildErrorView() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.cloud_off_rounded, size: 64, color: AppTheme.danger),
            const SizedBox(height: 16),
            Text(_error!, textAlign: TextAlign.center, style: const TextStyle(fontSize: 15)),
            const SizedBox(height: 24),
            ElevatedButton.icon(onPressed: _loadData, icon: const Icon(Icons.refresh), label: const Text('Reintentar')),
          ],
        ),
      ),
    );
  }

  Widget _buildContent(bool isDark) {
    return ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.all(20),
      children: [
        Text('¡Hola, $_userName!', style: GoogleFonts.manrope(fontSize: 26, fontWeight: FontWeight.w800)),
        const SizedBox(height: 4),
        Text('Panel de Control Farmacéutico', style: TextStyle(fontSize: 15, color: isDark ? Colors.white60 : AppTheme.neutralGrey)),
        const SizedBox(height: 28),

        _StatCard(
          icon: Icons.inventory_2_rounded,
          label: 'Stock Total',
          value: '$_totalStock',
          color: AppTheme.brandGreen,
          isDark: isDark,
          onTap: () => Navigator.pushNamed(context, '/inventory-list'),
        ),
        const SizedBox(height: 14),
        _StatCard(
          icon: Icons.warning_amber_rounded,
          label: 'Alertas de Vencimiento',
          value: '$_alertas',
          color: AppTheme.warning,
          isDark: isDark,
          onTap: () => Navigator.pushNamed(context, '/report'),
        ),
        const SizedBox(height: 14),
        _StatCard(
          icon: Icons.qr_code_scanner_rounded,
          label: 'Escaneos Hoy',
          value: '$_escaneos',
          color: const Color(0xFF6366F1),
          isDark: isDark,
        ),
        const SizedBox(height: 32),

        const Text('Acciones Rápidas', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
        const SizedBox(height: 14),
        
        _ActionButton(
          icon: Icons.medical_services_rounded,
          label: 'Registrar Medicamento',
          subtitle: 'Añadir nuevo producto al catálogo',
          color: AppTheme.brandGreen,
          onTap: () => Navigator.pushNamed(context, '/register-medicine'),
        ),
        const SizedBox(height: 12),
        _ActionButton(
          icon: Icons.qr_code_scanner_rounded,
          label: 'Escanear Medicamento',
          subtitle: 'Verificar autenticidad inmediata',
          color: const Color(0xFF6366F1),
          onTap: () => Navigator.pushNamed(context, '/scanner'),
        ),
        const SizedBox(height: 12),
        _ActionButton(
          icon: Icons.inventory_rounded,
          label: 'Ver Inventario',
          subtitle: 'Consultar existencias actuales',
          color: const Color(0xFF0EA5E9),
          onTap: () => Navigator.pushNamed(context, '/inventory-list'),
        ),
        const SizedBox(height: 12),
        _ActionButton(
          icon: Icons.bar_chart_rounded,
          label: 'Reportes',
          subtitle: 'Análisis de stock y vencimientos',
          color: AppTheme.warning,
          onTap: () => Navigator.pushNamed(context, '/report'),
        ),
        
        const SizedBox(height: 32),

        const Text('Movimientos Recientes', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
        const SizedBox(height: 14),
        _buildHistoryItem(Icons.add_task_rounded, 'Lote registrado con éxito', 'Hace 5 minutos', AppTheme.brandGreen, isDark),
        _buildHistoryItem(Icons.verified_user_rounded, 'Medicamento verificado', 'Hace 20 minutos', const Color(0xFF6366F1), isDark),
        _buildHistoryItem(Icons.inventory_2_rounded, 'Actualización de stock', 'Hace 1 hora', const Color(0xFF0EA5E9), isDark),

        const SizedBox(height: 100),
      ],
    );
  }

  Widget _buildHistoryItem(IconData icon, String title, String time, Color color, bool isDark) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: isDark ? AppTheme.darkSurface : Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: isDark ? Colors.white10 : Colors.grey.shade100),
      ),
      child: ListTile(
        leading: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(color: color.withOpacity(0.1), shape: BoxShape.circle),
          child: Icon(icon, color: color, size: 20),
        ),
        title: Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
        subtitle: Text(time, style: TextStyle(fontSize: 12, color: isDark ? Colors.white38 : Colors.grey)),
        dense: true,
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color color;
  final bool isDark;
  final VoidCallback? onTap;

  const _StatCard({required this.icon, required this.label, required this.value, required this.color, required this.isDark, this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: isDark ? AppTheme.darkSurface : Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: isDark ? [] : [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 12, offset: const Offset(0, 4))],
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(color: color.withOpacity(0.12), borderRadius: BorderRadius.circular(14)),
              child: Icon(icon, color: color, size: 28),
            ),
            const SizedBox(width: 18),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(label, style: TextStyle(fontSize: 13, color: isDark ? Colors.white60 : AppTheme.neutralGrey, fontWeight: FontWeight.w500)),
                  const SizedBox(height: 4),
                  Text(value, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
                ],
              ),
            ),
            if (onTap != null) Icon(Icons.chevron_right_rounded, color: isDark ? Colors.white24 : Colors.grey.shade300),
          ],
        ),
      ),
    );
  }
}

class _ActionButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final String subtitle;
  final Color color;
  final VoidCallback onTap;

  const _ActionButton({required this.icon, required this.label, required this.subtitle, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Material(
      color: isDark ? AppTheme.darkSurface : Colors.white,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(color: color.withOpacity(0.12), borderRadius: BorderRadius.circular(10)),
                child: Icon(icon, color: color, size: 24),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(label, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
                    const SizedBox(height: 2),
                    Text(subtitle, style: TextStyle(fontSize: 12, color: isDark ? Colors.white54 : AppTheme.neutralGrey)),
                  ],
                ),
              ),
              Icon(Icons.chevron_right_rounded, color: isDark ? Colors.white30 : Colors.grey.shade400),
            ],
          ),
        ),
      ),
    );
  }
}
